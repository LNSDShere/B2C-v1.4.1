# Build Flappy Bird, step by step

This tutorial builds the complete game in six short steps. Every step is a
runnable program, and every step adds one idea. By the end you will have
used most of the language and half of the game kit without noticing.

```
dec run examples/flappy-steps/step-1.dep     # ...through step-6.dep
dec run examples/flappy.dep                  # the finished game
dec run examples/flappy-art.dep              # the same game, with pictures
```

The only thing you need to know beforehand: `dec tour` lessons 1 to 10.

## The plan

Flappy Bird is four small ideas wearing one bird costume:

1. **A picture** -- sky, ground, a yellow circle.
2. **Gravity** -- a number that grows every frame and moves the bird down.
3. **Pipes** -- a list of maps that march left and recycle.
4. **A state machine** -- `ready`, `playing`, `over` -- so the same space
   key can mean "start", "flap", and "try again".

That's the whole game. Everything else is polish.

## Step 1 -- Put a bird in the sky

> File: `examples/flappy-steps/step-1.dep`

Every game has the same skeleton: make the game, then `every frame` draws
the world, then `run game` starts the loop.

```
use game kit

make game "Flappy Bird" with width 400 and height 600

set bird to {x: 100, y: 250, w: 34, h: 26}

every frame
  clear "sky blue"
  box 0, 520, 400, 80, "tan"             # the ground
  box 0, 520, 400, 16, "light green"     # grass

  circle bird.x + 17, bird.y + 13, 14, "yellow"    # body
  circle bird.x + 22, bird.y + 8, 4, "white"       # eye
  circle bird.x + 24, bird.y + 8, 2, "black"       # pupil
  box bird.x + 28, bird.y + 12, 10, 6, "orange"    # beak
end

run game
```

Three things to notice:

* The bird is a **map** -- a value with named fields. `x` and `y` are the
  top-left corner of an invisible 34x26 box. That box will matter in
  step 4, when we crash into things.
* Drawing is **painter's order**: whatever you draw later lands on top.
  Sky, then ground, then bird. Same reason you paint a wall before you
  hang a picture.
* `bird.x + 17` puts the circle's *center* in the middle of the box.
  Numbers everywhere, no magic -- 17 is half of 34.

## Step 2 -- Gravity and the flap

> File: `examples/flappy-steps/step-2.dep`

The real trick of Flappy-style movement is that you never move the bird
directly. You move a **velocity**, and the velocity moves the bird:

```
set vy to 0          # fall speed right now (negative = up)
set gravity to 1500  # pull, per second per second
set flap_v to -430   # the boost one flap gives

every frame
  change vy by gravity * delta      # gravity speeds up the fall...
  change bird.y by vy * delta       # ...and the fall moves the bird
  if pressed "space"
    set vy to flap_v                # one flap = one kick upward
  end
```

Two ideas doing all the work:

* **`delta`** is how long this frame took (in seconds). Multiplying by it
  means "per second" speeds behave the same at 30 or 60 fps. Moving
  without `delta` ties your game to one machine's speed.
* **`pressed` vs `holding`**: `pressed "space"` is true for exactly the
  frame the key goes down -- one flap per tap. `holding` would fire every
  frame while the key stays down, and the bird would become a helicopter.

Step 2 also clamps the bird to the screen -- bump the ceiling, land on the
floor. The pattern is always the same three lines: check, correct, zero
the velocity.

## Step 3 -- Pipes that march

> File: `examples/flappy-steps/step-3.dep`

One pipe would be boring, so we keep a **list** of them. Each pipe is a
map that stores only where the *gap* is; the two green boxes are drawn
from it:

```
set pipes to []

function new_pipe
  add {x: 410, w: pipe_w, gap_y: random(80, 290), gap_h: gap_h} to pipes
end
```

Spawning is distance-based, not timer-based: whenever the newest pipe has
drifted far enough left, add another just off-screen. This self-heals at
any framerate -- the world tells you when it needs a pipe:

```
if count of pipes is 0
  new_pipe
else
  set tail to last of pipes
  if tail.x is less than 180 then new_pipe
end
```

Moving and deleting happens in one backwards walk:

```
repeat with i from count of pipes to 1 by -1
  set pipe to pipes[i]                  # the real pipe, not a copy
  change pipe.x by -pipe_speed * delta
  if pipe.x is less than -70            # fully off-screen?
    remove item i from pipes
  end
end
```

Why backwards? Removing item 3 shuffles items 4, 5, 6 down a slot. If
you were walking forwards you'd skip one. Walking backwards, the shuffling
happens behind you, where you've already been. (Try it forwards -- the
game mostly works, then doesn't. Best bug lesson in this tutorial.)

And a small but mighty detail: `set pipe to pipes[i]` gives you the pipe
itself, not a copy -- maps are shared. That's why `change pipe.x` inside
the loop moves the pipe everyone else can see.

## Step 4 -- Crash and score

> File: `examples/flappy-steps/step-4.dep`

Time to lose. The game gets a `state` -- just a text -- and two of its
three gears exist by the end of this step: `"playing"` and `"over"`.

Scoring is a **flag on the pipe**. A pipe is worth one point during
exactly one moment: the frame its trailing edge crosses the bird. The
flag remembers "already counted":

```
if pipe.scored is no and pipe.x + pipe.w is less than bird.x
  set pipe.scored to yes
  change score by 1
end
```

Crashing uses `hits`, which checks two boxes for overlap. The gap is a
*hole*, so we build the two solid boxes around it on the fly and test
against both:

```
set top to {x: pipe.x, y: 0, w: pipe.w, h: pipe.gap_y}
set bottom to {x: pipe.x, y: pipe.gap_y + pipe.gap_h,
               w: pipe.w, h: 520 - pipe.gap_y - pipe.gap_h}
if bird hits top or bird hits bottom
  game_over
end
```

Remember the invisible box from step 1? This is why it exists. Circle
for the eyes, box for the bruises.

When `game_over` runs, the state flips and the whole `every frame` turns
into a different program: pipes freeze, the bird keeps its physics and
tumbles to the ground. One `if state is ...` per section -- no clever
tricks, just a machine with labeled gears.

## Step 5 -- Ready, set, go

> File: `examples/flappy-steps/step-5.dep`

The third gear: `"ready"`. Now the space key has three meanings --
start, flap, retry -- and the state decides which:

```
if pressed "space"
  if state is "ready" then start_game
  if state is "playing" then set vy to flap_v
  if state is "over" and over_pause is at most 0 then start_game
end
```

`over_pause` is a half-second delay after a crash, so the finger that's
still mashing space doesn't skip the game-over screen you worked for.

The best score earns its keep on disk:

```
function game_over
  ...
  if score is more than best
    set best to score
    save "flappy-best.txt", text best
  end
end

when game starts
  set saved to load "flappy-best.txt"     # nothing if it's not there
  if saved is not nothing
    set best to number saved
  end
end
```

Three quiet lessons in six lines: `load` gives `nothing` for a missing
file (no crash); `nothing` is false-ish so one `if` guards it; and
"only save when you beat it" means the file can never lie downward.

On the ready screen the bird bobs without any physics --
`set bird.y to 250 + sin(time * 3) * 8` -- three oscillations a second,
eight pixels of amplitude. `sin` is a free animation machine.

## Step 6 -- Make it yours

> File: `examples/flappy-steps/step-6.dep`
> The finished game: `examples/flappy.dep`

Polish is just more of what you already know:

* **Clouds** are a list of small maps drifting slower than the pipes.
  Two speeds = fake depth = *parallax*. When a cloud walks off the left,
  it re-enters on the right -- a cheap infinite world.
* **The wing** is a small box whose height is
  `bird.y + 14 + sin(time * 14) * 3` -- fourteen beats a second. That
  same `sin` trick, faster.
* **The ground scrolls**: a pattern offset that grows by
  `pipe_speed * delta` and wraps at the pattern width. The bird never
  moves; the world moves past it. Now you know why `bird.x` never changes.
* **Sounds**: `sound "examples/assets/flap.wav"` on the flap,
  `point.wav` when a pipe counts, `hit.wav` on the crash.
* **Mood**: the bird turns salmon after a crash -- one `if` before the
  draw calls.

## Using your own art

> Files: `examples/flappy-art.dep` (the whole game on art),
> `examples/assets/bird.png`, `background.png`, `pillars.png`

Suppose you have three files instead of a box of crayons:

* `bird.png` -- a **2-frame sprite sheet**: wings up in frame 1,
  wings down in frame 2, side by side in one picture
* `background.png` -- sky, clouds, hills
* `pillars.png` -- one pipe: a wide cap on top of a narrower shaft

The game doesn't change. Physics, pipes, scoring, states -- all of step 1
through 6 stays exactly as it is. Only the *drawing* section changes, and
the `image` command grows a few English options to do it.

**The bird, animated.** The sheet is two frames wide, so `frame pose of 2`
draws one of them -- `pose` is just a number you flip between 1 and 2:

```
set pose to 1
set anim_t to 0

every frame
  ...
  change anim_t by delta
  set beat to 0.15                      # seconds per wing beat
  if vy is less than 0
    set beat to 0.08                    # beat faster while rising
  end
  if anim_t is at least beat
    set anim_t to 0
    if pose is 1
      set pose to 2
    else
      set pose to 1
    end
  end
  ...
  image "examples/assets/bird.png", bird.x, bird.y, 34, 26, frame pose of 2
```

One detail worth noticing: the hitbox (`bird.w`, `bird.h`) and the art
size don't have to match. Keeping the hitbox a little *smaller* than the
picture is the standard kindness -- players forgive a game that says
"missed" when it looked close, and never the reverse.

**The background, scrolling.** Two copies of the same picture, sliding
left and wrapping around, make an endless world. It moves slower than
the pipes, which reads as *distance*:

```
change bg_x by -40 * delta
if bg_x is at most -400
  change bg_x by 400
end
...
image "examples/assets/background.png", bg_x, 0
image "examples/assets/background.png", bg_x + 400, 0
```

(The second copy draws where the first one has already left. When
`bg_x` wraps, they swap roles and nobody can tell.)

**The pipes, cropped and flipped.** One pipe picture has to play two
roles: the pipe above the gap and the pipe below it. `part` draws a
rectangle *out of* the picture (pixels counted from 0, like in an image
editor), and `flipped` turns it upside down:

```
function draw_pipe with p
  # top pipe: shaft stretched up to the gap, cap below it, both flipped
  image "examples/assets/pillars.png", p.x + 4, 0, 62, p.gap_y - 18,
        part 4, 18, 62, 502, flipped
  image "examples/assets/pillars.png", p.x, p.gap_y - 18, 70, 18,
        part 0, 0, 70, 18, flipped
  # bottom pipe: cap on top of the shaft, the right way up
  image "examples/assets/pillars.png", p.x, p.gap_y + p.gap_h, 70, 18,
        part 0, 0, 70, 18
  image "examples/assets/pillars.png", p.x + 4, p.gap_y + p.gap_h + 18, 62,
        sky_h - p.gap_y - p.gap_h - 18, part 4, 18, 62, 502
end
```

Why four draws? The cap and the shaft stretch differently: the shaft can
squash and stretch to any height and look fine, but a cap stretched to
3 pixels looks broken. So the shaft stretches (`part 4, 18, 62, 502` --
the middle 62 pixels of the picture, below the cap) and the cap draws at
its natural 70 by 18. When both pieces come from one file, your artist
keeps one pipe to maintain instead of four.

Wrapping the four draws in one function is the real lesson: **a pipe is
still just a pipe**, whether it's two boxes or four image calls. The
game logic never knows the difference.

If your `bird.png` were two separate files instead, the same animation
works with a plain `if` choosing between two `image` calls. And if your
bird should face left sometimes: `mirrored`.

## The tuning table

The feel of the game lives in four numbers. Change one, run, feel:

| Name          | Value | What it controls                                          |
|---------------|-------|-----------------------------------------------------------|
| `gravity`     | 1500  | heavier = sluggish jumps. Halve it for floaty moon mode    |
| `flap_v`      | -430  | kick strength. Further below zero = taller, riskier hops  |
| `gap_h`       | 150   | the hole. 120 is mean, 200 is kindergarten                 |
| `pipe_speed`  | 170   | world speed. Also decides how close pipes feel            |

A good sanity check for any pair: one flap should rise the bird about a
third of the gap. Ours rises ~61 pixels against a 150-pixel gap.

## Exercises

Each is a few lines in `examples/flappy.dep`. In rough order of effort:

1. **Night mode** -- after 10 points, `clear "night blue"` and make the
   clouds dim. You've met every tool you need.
2. **Medals** -- on the game-over screen, write "bronze" at 10,
   "silver" at 20, "gold" at 30. Three `if`s and a `write`.
3. **Squeeze** -- every point, `change gap_h by -2` down to a limit of
   110. The `min` function can hold the floor... or an `if`.
4. **Bobbing pipes** -- pipes that drift up and down with
   `sin(time * 2 + pipe.gap_y)`. Careful: collision uses `gap_y` too,
   so move it in one place.
5. **Two birds** -- a second bird on `pressed "w"`, first to crash buys
   the other a point. You'll want a `bird2` map, a `vy2`, and honesty
   about which collisions kill whom.

When something breaks, print the suspects (`print bird.y, vy`), run it,
and read what the numbers do. That habit -- not any one feature -- is
what actually finishes games.
