@echo off
title DeadEnd Setup
setlocal EnableExtensions
cd /d "%~dp0"

echo(
echo  ==================================================
echo    DeadEnd v1.4.0  --  Windows install
echo  ==================================================
echo(
echo  This installer will:
echo    [1] check for Python 3  (it does not install Python for you)
echo    [2] check the C compiler used by "Build .exe"
echo    [3] add DeadEnd Studio and Tour shortcuts to your desktop
echo(
echo  Everything stays inside this folder -- no admin rights needed.
echo  To uninstall later: delete this folder and the two shortcuts.
echo(
echo  Press any key to start, or close this window to cancel.
pause >nul

rem -- guard: launched straight from inside the ZIP viewer --
if exist "src\dec.py" goto :findpy
echo(
echo  DeadEnd cannot find src\dec.py next to this file.
echo(
echo  You probably double-clicked install.bat straight inside the ZIP
echo  window. Windows only unpacks this one .bat file to a temp folder.
echo(
echo  Fix: right-click the ZIP, choose "Extract All...", open the
echo  extracted folder, then double-click install.bat there.
echo(
pause
exit /b 1

:findpy
set "PYEXE="
if exist "tools\python\python.exe" set "PYEXE=tools\python\python.exe"
if defined PYEXE goto :havepy

py -3 -c "print(1)" >nul 2>&1
if not errorlevel 1 set "PYEXE=py -3"
if defined PYEXE goto :havepy

python -c "print(1)" >nul 2>&1
if not errorlevel 1 set "PYEXE=python"
if defined PYEXE goto :havepy

python3 -c "print(1)" >nul 2>&1
if not errorlevel 1 set "PYEXE=python3"
if defined PYEXE goto :havepy

goto :nopython

:havepy
echo(
echo  [1/4] Python found:  %PYEXE%
%PYEXE% "src\dec.py" version

echo(
echo  [2/4] Checking the toolchain (C compiler + smoke test)...
echo(
%PYEXE% "src\dec.py" doctor

rem -- if no GCC anywhere, print exactly how to get one --
if exist "tools\mingw64\bin\gcc.exe" goto :gccok
where gcc >nul 2>&1
if not errorlevel 1 goto :gccok
echo(
echo  NOTE: no C compiler found yet. Writing and running programs from
echo  Studio works, but "Build .exe" needs GCC (MinGW-w64). To add it:
echo(
echo    1. go to   https://winlibs.com/
echo    2. download the latest "Win64" release (UCRT runtime is fine)
echo    3. unzip it anywhere, for example  C:\mingw64
echo    4. add  C:\mingw64\bin  to your PATH:
echo       Start button -^> type "environment" -^> open
echo       "Edit environment variables for your account"
echo       -^> select Path -^> Edit -^> New -^> C:\mingw64\bin -^> OK
echo    5. run install.bat again (done steps are skipped)
goto :shortcuts

:gccok
echo(
echo  C compiler: ready -- "Build .exe" will work.

:shortcuts
echo(
echo  [3/4] Adding desktop shortcuts...
set "PKG=%~dp0"
set "DECBAT=%~dp0dec.bat"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $d=[Environment]::GetFolderPath('Desktop'); $s=$w.CreateShortcut($d+'\DeadEnd Studio.lnk'); $s.TargetPath='%DECBAT%'; $s.Arguments='studio'; $s.WorkingDirectory='%PKG%'; $s.IconLocation='%SystemRoot%\System32\SHELL32.dll,25'; $s.Save()" >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $d=[Environment]::GetFolderPath('Desktop'); $s=$w.CreateShortcut($d+'\DeadEnd Tour.lnk'); $s.TargetPath='%DECBAT%'; $s.Arguments='tour'; $s.WorkingDirectory='%PKG%'; $s.IconLocation='%SystemRoot%\System32\SHELL32.dll,22'; $s.Save()" >nul 2>&1
echo  Done.

rem ------------------------------------------------------------------
rem  [4/4] Put a tiny dec.cmd shim into the per-user WindowsApps
rem  folder (already on every user's PATH), so "dec" works in every
rem  terminal from every folder -- not just from this one.
rem  Bug fix (25): before this, opening a cmd in any other folder and
rem  typing dec just said "'dec' is not recognized".
rem ------------------------------------------------------------------
set "SHIMDIR=%LOCALAPPDATA%\Microsoft\WindowsApps"
set "SHIM=%SHIMDIR%\dec.cmd"
if exist "%SHIMDIR%\." goto :mkshim
mkdir "%SHIMDIR%" >nul 2>&1
:mkshim
echo(
echo  [4/4] Making "dec" work from every folder...
if not exist "%SHIMDIR%\." goto :noshimdir
> "%SHIM%" echo @echo off
>> "%SHIM%" echo rem DeadEnd shim created by install.bat -- delete this file to uninstall
>> "%SHIM%" echo call "%~dp0dec.bat" %%*
if exist "%SHIM%" goto :shimok
echo  NOTE: could not write %SHIM% -- skipping.
goto :shimdone
:shimok
echo  Done. Open a NEW terminal: "dec" now works in every folder.
echo  To uninstall later, delete: %SHIM%
goto :shimdone
:noshimdir
echo  NOTE: could not create %SHIMDIR% -- skipping.
echo  You can still run dec.bat from this folder, or add this folder
echo  to your PATH: %~dp0
:shimdone

echo(
echo  ==================================================
echo    Install finished.
echo  ==================================================
echo(
echo    - double-click "DeadEnd Studio" on your desktop,
echo      write some English, press Run.
echo    - or double-click "DeadEnd Tour" for a ~20 minute
echo      interactive tour of the whole language.
echo    - from a terminal:   dec run myprogram.dep
echo(
echo  If anything went wrong above, select the text with the
echo  mouse and press Enter to copy it, then send it for help.
echo(
echo  Press any key to close this window.
pause >nul
exit /b 0

:nopython
echo(
echo  ==================================================================
echo   Step 1 of 4 stopped: Python 3 (3.8 or newer) was not found.
echo   This is the one thing DeadEnd cannot install for you. To fix:
echo(
echo     1. Go to   https://www.python.org/downloads/
echo     2. Download Python 3 and run the installer.
echo     3. IMPORTANT: on the first installer screen, tick the box
echo        "Add python.exe to PATH" before clicking Install Now.
echo     4. Run install.bat again -- it will finish the rest.
echo(
echo   Or: open the Microsoft Store, search for "Python 3.12",
echo   install it, then run install.bat again.
echo  ==================================================================
echo(
pause
exit /b 1
