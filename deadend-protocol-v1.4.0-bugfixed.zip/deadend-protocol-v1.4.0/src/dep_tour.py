"""The DeadEnd interactive tour.

Run `dec tour` and it walks you through the whole language, lesson by
lesson, running real programs as it goes.
"""
import os
import subprocess
import sys
import tempfile

BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[36m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RESET = "\033[0m"

LESSONS = [
    {
        "title": "Welcome to DeadEnd",
        "text": [
            "DeadEnd is a programming language that reads like English and runs at the speed of C,",
            "because it compiles to real native code (plain C, optimized by gcc/clang).",
            "",
            "A DeadEnd program is a list of plain-English sentences. Every sentence starts on",
            "its own line. Comments start with #.",
        ],
        "code": """# my first DeadEnd program
print "Hello, world!"
print "I am running at C speed." """,
    },
    {
        "title": "Values: set ... to ...",
        "text": [
            "You keep values in names with 'set ... to ...'. Text lives in quotes,",
            "numbers are just numbers, and 'yes' / 'no' answer questions.",
            "",
            "Printing several values with commas puts a space between them.",
        ],
        "code": """set name to "Ada"
set age to 36
set paid to yes

print "Name:", name
print "Age:", age
print "Paid up?", paid

# text joins with +
print name + " is " + age + " years old\"""",
    },
    {
        "title": "Decisions: if / else / end",
        "text": [
            "Comparisons read like sentences: 'is', 'is not', 'is more than', 'is at least'...",
            "Every block ends with the word 'end'. One-liners can use 'then'.",
            "",
            "Only 'no', 'nothing', 0 and \"\" count as false -- everything else is true.",
        ],
        "code": """set temperature to 30

if temperature is more than 25
  print "It's warm."
else
  print "Bring a jacket."
end

set name to "Ada"
if name is "Ada" then print "Hello, Ada!"

if name is not "Bob" and temperature is at least 20
  print "Nice day for it."
end""",
    },
    {
        "title": "Repetition",
        "text": [
            "Repeat things a number of times, count through a range, or loop while something holds.",
            "'change ... by ...' adds to a value. 'break' leaves a loop, 'continue' skips ahead.",
        ],
        "code": """repeat 3 times
  print "Going..."
end

repeat with i from 1 to 5
  print i, "squared is", i * i
end

repeat with i from 10 to 1 by -2
  print i
end

set fuel to 3
while fuel is more than 0
  change fuel by -1
end
print "fuel:", fuel

repeat with i from 1 to 100
  if i is 3 then break
end
print "stopped at", i""",
    },
    {
        "title": "Lists",
        "text": [
            "Lists hold many values: [1, 2, 3]. Positions start at 1.",
            "'add ... to ...' appends. 'count of' measures. 'has' checks membership.",
            "'for each ... in ...' walks through every item.",
        ],
        "code": """set planets to ["Mercury", "Venus", "Earth"]

add "Mars" to planets
print planets
print "the first planet is", planets[1]
print "we know", count of planets, "planets"

if planets has "Earth"
  print "home sweet home"
end

for each planet in planets
  print planet, "has", count of planet, "letters"
end

set scores to [42, 7, 99, 13]
sort scores
print scores""",
    },
    {
        "title": "Maps: values with fields",
        "text": [
            "A map is a value with named fields -- perfect for things in your program.",
            "Read with dot. Write with 'set ... to ...'. 'change' works on fields too.",
        ],
        "code": """set hero to {name: "Ada", x: 100, y: 50, health: 10}

print hero.name, "stands at", hero.x, hero.y

set hero.x to 160
change hero.health by -3

print "health is now", hero.health
print "the map has", count of hero, "fields"

if hero has "name"
  print "still called", hero.name
end""",
    },
    {
        "title": "Functions",
        "text": [
            "Functions take values 'with a and b' and give values back with 'return'.",
            "Call them as a command (greet \"Ada\") or where a value is needed (add(2, 3)).",
            "Recursion works -- and it runs at C speed.",
        ],
        "code": """function greet with name
  print "Hello, " + name + "!"
end
greet "Ada"

function add with a and b
  return a + b
end
print add(2, 3)

function factorial with n
  if n is at most 1
    return 1
  end
  return n * factorial(n - 1)
end
print "10! is", factorial(10)

function roll_dice
  return random 1, 6
end
print "you rolled", roll_dice""",
    },
    {
        "title": "Text and numbers toolbox",
        "text": [
            "The built-in words do the common jobs. Count letters, cut, join, search, replace,",
            "convert between text and numbers, use math and random.",
        ],
        "code": """set phrase to "  DeadEnd rocks  "
print count of trim phrase, "letters"
print upper "quiet"
print split("a,b,c", ",")
print join(["x", "y", "z"], "-")

print "found at position", find("Hello", "llo")
print replace("cats and dogs", "and", "or")

print number "3.14" + 1
print text 7 + "!"

print "sqrt 144 is", sqrt 144
print "2 to the 10th is", power(2, 10)
print "a coin flip says", random 0, 1""",
    },
    {
        "title": "Files",
        "text": [
            "Save and load whole files in one word each. 'load' gives 'nothing' if the file is missing.",
        ],
        "code": """save "note.txt", "buy milk"
set contents to load "note.txt"
print "the file says:", contents

if exists "note.txt"
  print "the file exists"
end
print "missing file gives:", load "nope.txt\"""",
    },
    {
        "title": "The 2D Game Kit",
        "text": [
            "'use game kit' turns on game powers: a window, frames, keys, mouse, drawing, collisions, sound.",
            "",
            "  make game \"Title\" with width 800 and height 600   -- create the game",
            "  when game starts ... end                            -- one-time setup",
            "  every frame ... end                                 -- your game loop (60 fps)",
            "  run game                                            -- play!",
            "",
            "This example runs a few frames then closes (the tour runs it that way on purpose).",
            "Move with the arrow keys when you run it yourself!",
        ],
        "code": """use game kit

make game "Dot Chase" with width 400 and height 300

set dot to {x: 200, y: 150, w: 16, h: 16}
set treat to {x: 60, y: 220, w: 10, h: 10}
set score to 0

when game starts
  print "catch the gold square!"
end

every frame
  if holding "left" then change dot.x by -4
  if holding "right" then change dot.x by 4
  if holding "up" then change dot.y by -4
  if holding "down" then change dot.y by 4

  if dot hits treat
    change score by 1
    print "score!", score
  end

  clear "night blue"
  circle dot.x, dot.y, 8, "gold"
  box treat.x, treat.y, treat.w, treat.h, "red"
  write "Score: " + score, 10, 10, 20, "white"
end

run game""",
        "kit": "game",
    },
    {
        "title": "The App Kit",
        "text": [
            "'use app kit' gives you windows with real widgets: titles, labels, buttons, fields,",
            "checkboxes, sliders, images and panels. Place them with 'at x, y', then wire buttons",
            "to 'when button ... is clicked' blocks.",
            "",
            "Read what someone typed with: field \"name\". Change labels with: set label \"name\" to ...",
        ],
        "code": """use app kit

make window "Greeter" with width 340 and height 240

add title "Say hello" at 16, 14
add label "Type your name:" at 16, 60
add field "who" at 16, 88 with width 200
add button "Greet" at 16, 126
add label "out" at 16, 180

when button "Greet" is clicked
  set label "out" to "Hello, " + field "who" + "!"
end

run app""",
        "kit": "app",
    },
    {
        "title": "The Motion Kit",
        "text": [
            "'move ... toward ...' animates any number toward a target. Add 'feeling bouncy',",
            "'lasting 2 seconds', 'waiting 0.5 seconds', 'reversing', 'repeating forever'...",
            "'spring ... toward ...' uses real physics -- tune it 'with speed 2' or 'with wobble 6'.",
            "",
            "Timelines chain steps: make one, 'add ... to timeline \"x\"', then play it.",
            "Ask questions: moving dot.x? playing \"intro\"? finished \"intro\"?",
            "",
            "This lesson steps time by hand with 'advance 1 second' so it prints -- in a real",
            "game or app the clock ticks every frame by itself. See examples/animation-showcase.dep.",
        ],
        "code": """set dot to {x: 0, y: 0}
set hp to 0

# a tween lands exactly on its target
move dot.x toward 100 lasting 1 second feeling bouncy
advance 1 second
print "x =", dot.x

# a spring settles like real physics
spring hp toward 50 with wobble 6
advance 3 seconds
print "hp =", hp

# timelines run steps one after another
make timeline "intro"
add move dot.y toward 80 lasting 1 second to timeline "intro"
add wait 0.5 seconds to timeline "intro"
add move dot.x toward 200 lasting 0.5 seconds to timeline "intro"
play timeline "intro"
advance 2.5 seconds
print "dot:", dot.x, dot.y
print "still moving?", moving dot.x

# multi-field moves read like a sentence
move dot toward {x: 10, y: 10} lasting 1 second
advance 1 second
print "back home:", dot.x, dot.y""",
    },
    {
        "title": "Project: Flappy Bird",
        "text": [
            "Everything you've learned, in one small game: maps, lists, functions,",
            "state, 'hits', 'last of', and walking a list backwards so removals are safe.",
            "",
            "Gravity is just a number that grows; a flap is just setting it negative.",
            "Pipes are maps in a list; the gap is where they aren't.",
            "",
            "Space to flap. When it crashes: the score prints, and 'exit' closes.",
            "The full game -- screens, best score, clouds, sounds -- is",
            "examples/flappy.dep, built one step at a time in docs/flappy-bird.md.",
        ],
        "code": """use game kit

make game "Flappy Mini" with width 300 and height 440

set bird to {x: 80, y: 200, w: 30, h: 24}
set vy to 0
set pipes to []
set score to 0

function new_pipe
  add {x: 310, gap_y: random(60, 220), gap_h: 130, w: 54, scored: no} to pipes
end

new_pipe

every frame
  if pressed "space"
    set vy to -400
  end
  change vy by 1400 * delta
  change bird.y by vy * delta

  set tail to last of pipes
  if tail.x is less than 130 then new_pipe

  repeat with i from count of pipes to 1 by -1
    set pipe to pipes[i]
    change pipe.x by -150 * delta
    if pipe.scored is no and pipe.x + pipe.w is less than bird.x
      set pipe.scored to yes
      change score by 1
    end
    set top to {x: pipe.x, y: 0, w: pipe.w, h: pipe.gap_y}
    set bottom to {x: pipe.x, y: pipe.gap_y + pipe.gap_h, w: pipe.w, h: 320}
    if bird hits top or bird hits bottom
      print "crash! score:", score
      exit
    end
    if pipe.x is less than -60
      remove item i from pipes
    end
  end

  if bird.y is more than 400
    print "crash! score:", score
    exit
  end

  clear "sky blue"
  for each pipe in pipes
    box pipe.x, 0, pipe.w, pipe.gap_y, "green"
    box pipe.x, pipe.gap_y + pipe.gap_h, pipe.w, 120, "green"
  end
  box 0, 400, 300, 40, "tan"
  circle bird.x + 15, bird.y + 12, 12, "yellow"
  write score, 135, 30, 30, "white"
end

run game""",
        "kit": "game",
    },
    {
        "title": "You know DeadEnd",
        "text": [
            "That's the whole language -- about 30 words, no symbols to memorize.",
            "And the motion kit adds animation in plain English: move, spring, timelines,",
            "particles and screen effects, in games and apps alike.",
            "",
            "Where to go next:",
            "  examples/     pong, a todo app, animation-showcase, menu-scene and more",
            "  docs/         the full language and kit references (start with animation-kit.md)",
            "",
            "Write a program:  dec run myfile.dep",
            "Make an app:      dec build myfile.dep",
            "",
            "The Dead-End Protocol says a failed method proves nothing about the task.",
            "Now you have a language that proves it. Go build something.",
        ],
        "code": """function encourage with who
  print who + ": the task is open."
end

encourage "you"
print "welcome to DeadEnd.\"""",
    },
]


def show_code(code):
    for line in code.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("#"):
            print(f"{DIM}{line}{RESET}")
        else:
            print(line)


def run_tour(root, compile_fn):
    print()
    print(f"{BOLD}{CYAN}  ___            _        ___ _   _  ___ ___ ")
    print(" |   \\ _ _  __ _| |_____ / __| | | |/ __| __|")
    print(" | |) | ' \\/ _` | / / -_) (__| |_| | (__| _| ")
    print(f" |___/|_||_\\__,_|_\\_\\___|\\___|\\___/ \\___|___|{RESET}")
    print(f"{BOLD}  the language that reads like English and runs like C{RESET}")
    print()
    print(f"  {DIM}n = next lesson   r = run this lesson's program   q = quit{RESET}")
    print()

    i = 0
    while i < len(LESSONS):
        lesson = LESSONS[i]
        print(f"{BOLD}{GREEN}--- Lesson {i + 1} of {len(LESSONS)}: {lesson['title']} ---{RESET}")
        print()
        for para in lesson["text"]:
            print(f"  {para}" if para else "")
        print()
        print(f"  {CYAN}{BOLD}the program:{RESET}")
        for line in lesson["code"].splitlines():
            show_code_indented(line)
        print()
        try:
            answer = input(f"  [{BOLD}n{RESET}=next, {BOLD}r{RESET}=run, {BOLD}q{RESET}=quit] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if answer == "q":
            break
        if answer == "r":
            path = os.path.join(tempfile.gettempdir(), f"dep_tour_{i}.dep")
            with open(path, "w", encoding="utf-8") as f:
                f.write(lesson["code"] + "\n")
            env = dict(os.environ)
            if lesson.get("kit"):
                env["DEP_FRAMES"] = "120"    # games/apps auto-close after 2 seconds in the tour
            try:
                r = subprocess.run([sys.executable, os.path.join(root, "src", "dec.py"),
                                    "run", path], env=env)
                if r.returncode != 0:
                    print(f"{YELLOW}  (the program did not finish cleanly){RESET}")
            except Exception as e:
                print(f"{YELLOW}  could not run: {e}{RESET}")
            print()
        i += 1

    print()
    print(f"{GREEN}Thanks for taking the tour. The road continues in examples/ and docs/.{RESET}")
    print()


def show_code_indented(line):
    DIMC = DIM
    RESETC = RESET
    stripped = line.lstrip()
    if stripped.startswith("#"):
        print(f"    {DIMC}{line}{RESETC}")
    else:
        print(f"    {line}")
