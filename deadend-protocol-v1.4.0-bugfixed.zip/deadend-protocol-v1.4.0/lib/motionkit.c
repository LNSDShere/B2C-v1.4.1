/* ==========================================================================
 * DeadEnd Motion Kit -- motionkit.c   (new in v1.4.0)
 *
 * The complete animation engine: 31 easing curves, tweens, physics springs,
 * named timelines, one-sentence particles, screen effects and UI motion.
 *
 * Pure C on top of dep_runtime types only -- the game kit and app kit render
 * what this engine computes, which is what lets console programs animate too
 * (with `advance 1 second` stepping time by hand).
 * ========================================================================== */
#include "motionkit.h"
#include <string.h>
#include <ctype.h>
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* forward declarations used across sections */
static int dep_m_ui_busy(const char *name);
static void (*m_ui_exec_hook)(int op, const char *name, double dur,
                              const char *feel, int dir, double x, double y,
                              double strength) = NULL;

/* ================= tiny helpers ================= */

static double m_clamp(double v, double lo, double hi) {
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static unsigned long long m_rng = 0x243F6A8885A308D3ULL;

static double m_rand(void) {           /* 0..1 */
    m_rng ^= m_rng << 13; m_rng ^= m_rng >> 7; m_rng ^= m_rng << 17;
    return (double)(m_rng & 0xFFFFFFFFFFFFULL) / 281474976710656.0;
}
static double m_rand_range(double lo, double hi) { return lo + (hi - lo) * m_rand(); }

static char *m_strdup(const char *s) {
    size_t n = strlen(s) + 1;
    char *r = (char *)malloc(n);
    if (r) memcpy(r, s, n);
    return r;
}

/* ================= 1. easing curves ================= */

/* the canonical bounce used by all three bounce curves */
static double m_bounce_out(double x) {
    double n1 = 7.5625, d1 = 2.75;
    if (x < 1.0 / d1) return n1 * x * x;
    if (x < 2.0 / d1) { x -= 1.5 / d1;  return n1 * x * x + 0.75; }
    if (x < 2.5 / d1) { x -= 2.25 / d1; return n1 * x * x + 0.9375; }
    x -= 2.625 / d1;
    return n1 * x * x + 0.984375;
}

double dep_m_ease(int curve, double t) {
    t = m_clamp(t, 0.0, 1.0);
    switch (curve) {
    case DEP_EASE_LINEAR: return t;
    /* --- sine --- */
    case DEP_EASE_SINE_IN:  return 1.0 - cos(t * M_PI / 2.0);
    case DEP_EASE_SINE_OUT: return sin(t * M_PI / 2.0);
    case DEP_EASE_SINE_INOUT: return -(cos(M_PI * t) - 1.0) / 2.0;
    /* --- quad --- */
    case DEP_EASE_QUAD_IN:  return t * t;
    case DEP_EASE_QUAD_OUT: return 1.0 - (1.0 - t) * (1.0 - t);
    case DEP_EASE_QUAD_INOUT:
        return t < 0.5 ? 2.0 * t * t : 1.0 - pow(-2.0 * t + 2.0, 2.0) / 2.0;
    /* --- cubic --- */
    case DEP_EASE_CUBIC_IN:  return t * t * t;
    case DEP_EASE_CUBIC_OUT: return 1.0 - pow(1.0 - t, 3.0);
    case DEP_EASE_CUBIC_INOUT:
        return t < 0.5 ? 4.0 * t * t * t : 1.0 - pow(-2.0 * t + 2.0, 3.0) / 2.0;
    /* --- quart --- */
    case DEP_EASE_QUART_IN:  return t * t * t * t;
    case DEP_EASE_QUART_OUT: return 1.0 - pow(1.0 - t, 4.0);
    case DEP_EASE_QUART_INOUT:
        return t < 0.5 ? 8.0 * t * t * t * t
                       : 1.0 - pow(-2.0 * t + 2.0, 4.0) / 2.0;
    /* --- quint --- */
    case DEP_EASE_QUINT_IN:  return t * t * t * t * t;
    case DEP_EASE_QUINT_OUT: return 1.0 - pow(1.0 - t, 5.0);
    case DEP_EASE_QUINT_INOUT:
        return t < 0.5 ? 16.0 * t * t * t * t * t
                       : 1.0 - pow(-2.0 * t + 2.0, 5.0) / 2.0;
    /* --- expo --- */
    case DEP_EASE_EXPO_IN:  return t == 0.0 ? 0.0 : pow(2.0, 10.0 * t - 10.0);
    case DEP_EASE_EXPO_OUT: return t == 1.0 ? 1.0 : 1.0 - pow(2.0, -10.0 * t);
    case DEP_EASE_EXPO_INOUT:
        if (t == 0.0) return 0.0;
        if (t == 1.0) return 1.0;
        return t < 0.5 ? pow(2.0, 20.0 * t - 10.0) / 2.0
                       : (2.0 - pow(2.0, -20.0 * t + 10.0)) / 2.0;
    /* --- circ --- */
    case DEP_EASE_CIRC_IN:  return 1.0 - sqrt(1.0 - t * t);
    case DEP_EASE_CIRC_OUT: return sqrt(1.0 - pow(t - 1.0, 2.0));
    case DEP_EASE_CIRC_INOUT:
        return t < 0.5
            ? (1.0 - sqrt(1.0 - pow(2.0 * t, 2.0))) / 2.0
            : (sqrt(1.0 - pow(-2.0 * t + 2.0, 2.0)) + 1.0) / 2.0;
    /* --- back (overshoots) --- */
    case DEP_EASE_BACK_IN: {
        double c1 = 1.70158, c3 = c1 + 1.0;
        return c3 * t * t * t - c1 * t * t;   /* dips below 0 first */
    }
    case DEP_EASE_BACK_OUT: {
        double c1 = 1.70158, c3 = c1 + 1.0;
        return 1.0 + c3 * pow(t - 1.0, 3.0) + c1 * pow(t - 1.0, 2.0);
    }
    case DEP_EASE_BACK_INOUT: {
        double c = 1.70158 * 1.525;
        return t < 0.5
            ? (pow(2.0 * t, 2.0) * ((c + 1.0) * 2.0 * t - c)) / 2.0
            : (pow(2.0 * t - 2.0, 2.0) * ((c + 1.0) * (t * 2.0 - 2.0) + c) + 2.0) / 2.0;
    }
    /* --- elastic (springs past the target) --- */
    case DEP_EASE_ELASTIC_IN: {
        if (t == 0.0 || t == 1.0) return t;
        double c = (2.0 * M_PI) / 3.0;
        return -pow(2.0, 10.0 * t - 10.0) * sin((t * 10.0 - 10.75) * c);
    }
    case DEP_EASE_ELASTIC_OUT: {
        if (t == 0.0 || t == 1.0) return t;
        double c = (2.0 * M_PI) / 3.0;
        return pow(2.0, -10.0 * t) * sin((t * 10.0 - 0.75) * c) + 1.0;
    }
    case DEP_EASE_ELASTIC_INOUT: {
        if (t == 0.0 || t == 1.0) return t;
        double c = (2.0 * M_PI) / 4.5;
        return t < 0.5
            ? -(pow(2.0, 20.0 * t - 10.0) * sin((20.0 * t - 11.125) * c)) / 2.0
            : (pow(2.0, -20.0 * t + 10.0) * sin((20.0 * t - 11.125) * c)) / 2.0 + 1.0;
    }
    /* --- bounce (lands like a ball) --- */
    case DEP_EASE_BOUNCE_IN:  return 1.0 - m_bounce_out(1.0 - t);
    case DEP_EASE_BOUNCE_OUT: return m_bounce_out(t);
    case DEP_EASE_BOUNCE_INOUT:
        return t < 0.5
            ? (1.0 - m_bounce_out(1.0 - 2.0 * t)) / 2.0
            : (1.0 + m_bounce_out(2.0 * t - 1.0)) / 2.0;
    default: return t;
    }
}

/* normalize a curve name: lowercase, drop '-', 'inout' -> 'in out' tokenless */
static void m_norm_name(const char *in, char *out, size_t cap) {
    size_t o = 0;
    for (const char *p = in; *p && o + 1 < cap; p++) {
        if (*p == '-' || *p == '_' || *p == ' ') continue;
        out[o++] = (char)tolower((unsigned char)*p);
    }
    out[o] = '\0';
}

typedef struct { const char *name; int id; } MEaseName;
static const MEaseName MEASES[] = {
    {"linear", DEP_EASE_LINEAR}, {"line", DEP_EASE_LINEAR},
    {"steady", DEP_EASE_LINEAR},
    {"sinein", DEP_EASE_SINE_IN}, {"sineout", DEP_EASE_SINE_OUT},
    {"sineinout", DEP_EASE_SINE_INOUT},
    {"quadin", DEP_EASE_QUAD_IN}, {"quadout", DEP_EASE_QUAD_OUT},
    {"quadinout", DEP_EASE_QUAD_INOUT},
    {"cubicin", DEP_EASE_CUBIC_IN}, {"cubicout", DEP_EASE_CUBIC_OUT},
    {"cubicinout", DEP_EASE_CUBIC_INOUT},
    {"quartin", DEP_EASE_QUART_IN}, {"quartout", DEP_EASE_QUART_OUT},
    {"quartinout", DEP_EASE_QUART_INOUT},
    {"quintin", DEP_EASE_QUINT_IN}, {"quintout", DEP_EASE_QUINT_OUT},
    {"quintinout", DEP_EASE_QUINT_INOUT},
    {"expoin", DEP_EASE_EXPO_IN}, {"expoout", DEP_EASE_EXPO_OUT},
    {"expoinout", DEP_EASE_EXPO_INOUT},
    {"circin", DEP_EASE_CIRC_IN}, {"circout", DEP_EASE_CIRC_OUT},
    {"circinout", DEP_EASE_CIRC_INOUT},
    {"backin", DEP_EASE_BACK_IN}, {"backout", DEP_EASE_BACK_OUT},
    {"backinout", DEP_EASE_BACK_INOUT},
    {"elasticin", DEP_EASE_ELASTIC_IN}, {"elasticout", DEP_EASE_ELASTIC_OUT},
    {"elasticinout", DEP_EASE_ELASTIC_INOUT},
    {"bouncein", DEP_EASE_BOUNCE_IN}, {"bounceout", DEP_EASE_BOUNCE_OUT},
    {"bounceinout", DEP_EASE_BOUNCE_INOUT},
    /* feeling words -- plain English for the same curves */
    {"smooth", DEP_EASE_CUBIC_INOUT},        /* the default */
    {"gentle", DEP_EASE_SINE_INOUT},
    {"soft", DEP_EASE_SINE_OUT},
    {"quick", DEP_EASE_CUBIC_OUT},
    {"swift", DEP_EASE_QUAD_OUT},
    {"building", DEP_EASE_CUBIC_IN},
    {"accelerating", DEP_EASE_QUAD_IN},
    {"creeping", DEP_EASE_QUAD_IN},
    {"dramatic", DEP_EASE_EXPO_INOUT},
    {"sharp", DEP_EASE_EXPO_OUT},
    {"explosive", DEP_EASE_EXPO_OUT},
    {"snappy", DEP_EASE_BACK_OUT},
    {"overshoot", DEP_EASE_BACK_OUT},
    {"overshooting", DEP_EASE_BACK_OUT},
    {"springy", DEP_EASE_ELASTIC_OUT},
    {"wobbly", DEP_EASE_ELASTIC_OUT},
    {"jelly", DEP_EASE_ELASTIC_INOUT},
    {"bouncy", DEP_EASE_BOUNCE_OUT},
    {"bouncing", DEP_EASE_BOUNCE_INOUT},
    {"landing", DEP_EASE_BOUNCE_OUT},
    {"punchy", DEP_EASE_BACK_INOUT},
    {"settling", DEP_EASE_QUINT_OUT},
    {"gliding", DEP_EASE_SINE_INOUT},
    {"floating", DEP_EASE_SINE_INOUT},
    {"zooming", DEP_EASE_EXPO_IN},
    {NULL, 0}
};

int dep_m_ease_id(const char *name) {
    if (!name || !name[0]) return DEP_EASE_CUBIC_INOUT;
    char norm[64], swap[64];
    m_norm_name(name, norm, sizeof norm);
    for (int f = 0; f < 2; f++) {
        const char *p = norm;
        if (strncmp(p, "ease", 4) == 0) p += 4;
        if (f == 1) {
            /* "ease-out-bounce" -> "outbounce": retry as "bounceout" */
            if (strncmp(p, "inout", 5) == 0) {
                snprintf(swap, sizeof swap, "%sinout", p + 5); p = swap;
            } else if (strncmp(p, "out", 3) == 0) {
                snprintf(swap, sizeof swap, "%sout", p + 3); p = swap;
            } else if (strncmp(p, "in", 2) == 0) {
                snprintf(swap, sizeof swap, "%sin", p + 2); p = swap;
            }
        }
        for (int i = 0; MEASES[i].name; i++)
            if (strcmp(p, MEASES[i].name) == 0) return MEASES[i].id;
    }
    return -1;
}

double dep_m_ease_call(DEPValue feel, DEPValue t) {
    const char *s = (feel.tag == DEP_T_TEXT) ? feel.as.s->chars : "";
    double p = (t.tag == DEP_T_NUM) ? t.as.n : 0.0;
    dep_release(feel);
    dep_release(t);
    int id = dep_m_ease_id(s);
    if (id < 0) dep_die("I don't know the feeling \"%s\" "
                        "(try bouncy, springy, snappy, smooth, quick...)", s);
    return dep_m_ease(id, p);
}

/* ================= 2. slots (tweens + springs) ================= */

typedef struct {
    int used;
    int kind;               /* 0 tween, 1 spring */
    int active;             /* issued, not finished */
    int running;            /* past its delay, writing values */
    int finished_ever;
    int frozen;             /* paused by a paused timeline: hold this value */
    /* tween */
    double from, to, value;
    double dur, t, delay, from_override;
    int has_from;
    int ease;
    double repeat_n;        /* -1 forever, else plays */
    int pingpong;
    /* spring */
    double vel, stiffness, damping, settle;
    /* bindings into generated code */
    double (*from_fn)(void);
    void (*write_fn)(double);
} MSlot;

static MSlot *m_slots = NULL;
static int m_slot_count = 0;
static int m_slot_cap = 0;

static MSlot *m_slot(int id) {
    if (id < 0) dep_die("bad animation slot");
    if (id >= m_slot_cap) {
        int cap = m_slot_cap ? m_slot_cap * 2 : 64;
        while (cap <= id) cap *= 2;
        m_slots = (MSlot *)realloc(m_slots, sizeof(MSlot) * (size_t)cap);
        if (!m_slots) dep_die("out of memory");
        for (int i = m_slot_cap; i < cap; i++)
            memset(&m_slots[i], 0, sizeof(MSlot));
        m_slot_cap = cap;
    }
    if (id >= m_slot_count) m_slot_count = id + 1;
    m_slots[id].used = 1;
    return &m_slots[id];
}

void dep_m_bind(int id, double (*from_fn)(void), void (*write_fn)(double)) {
    MSlot *s = m_slot(id);
    s->from_fn = from_fn;
    s->write_fn = write_fn;
}

static void m_write(MSlot *s, double v) {
    s->value = v;
    if (s->write_fn) s->write_fn(v);
}

void dep_m_move(int id, const char *feel, double to, double dur,
                double delay, double repeat_n, int pingpong,
                double from, int has_from) {
    MSlot *s = m_slot(id);
    if (repeat_n <= 0 && repeat_n != -1) repeat_n = 1;   /* 0 means "once" */
    if (s->active && s->kind == 0 && fabs(to - s->to) < 1e-9)
        return;                       /* already heading there: keep going */
    s->kind = 0;
    s->to = to;
    s->dur = dur > 0.0001 ? dur : 0.0001;
    s->delay = delay > 0 ? delay : 0;
    s->repeat_n = repeat_n;
    s->pingpong = pingpong ? 1 : 0;
    s->has_from = has_from;
    s->from_override = from;
    s->ease = dep_m_ease_id(feel);
    if (s->ease < 0)
        dep_die("I don't know the feeling \"%s\" "
                "(try bouncy, springy, snappy, smooth, quick...)", feel ? feel : "");
    s->active = 1;
    s->running = 0;                   /* delay phase first (delay may be 0) */
    s->frozen = 0;
    s->t = 0;
    s->settle = 0;
}

void dep_m_spring(int id, double to, double stiffness, double damping) {
    MSlot *s = m_slot(id);
    if (s->active && s->kind == 1 && fabs(to - s->to) < 1e-9)
        return;
    if (!(stiffness > 0)) stiffness = 170.0;
    if (!(damping > 0)) damping = 26.0;
    s->kind = 1;
    s->to = to;
    s->stiffness = stiffness;
    s->damping = damping;
    s->dur = 0;
    s->delay = 0;
    s->active = 1;
    s->running = 0;
    s->frozen = 0;
    s->t = 0;
    s->settle = 0;
    s->vel = 0;
}

int dep_m_active(int id) {
    if (id < 0 || id >= m_slot_count) return 0;
    return m_slots[id].active;
}

double dep_m_value(int id) {
    if (id < 0 || id >= m_slot_count) return 0.0;
    return m_slots[id].value;
}

void dep_m_stop(int id) {
    if (id < 0 || id >= m_slot_count) return;
    MSlot *s = &m_slots[id];
    if (s->active) m_write(s, s->value);   /* freeze where it is */
    s->active = 0;
    s->running = 0;
    s->frozen = 0;
}

void dep_m_stop_range(int lo, int hi) {
    for (int i = lo; i <= hi; i++) dep_m_stop(i);
}

int dep_m_any_active(void) {
    for (int i = 0; i < m_slot_count; i++)
        if (m_slots[i].active) return 1;
    return 0;
}

/* ---- slot tick ---- */

static void m_slot_tick(MSlot *s, double dt) {
    if (!s->active || s->frozen) return;
    double step = dt;
    if (!s->running) {
        s->delay -= dt;
        if (s->delay > 0) return;
        /* start now: read the fresh starting value */
        if (s->has_from) s->from = s->from_override;
        else if (s->from_fn) s->from = s->from_fn();
        else s->from = 0;
        if (s->kind == 1) { s->vel = 0; s->value = s->from; }
        s->running = 1;
        if (s->kind == 1) return;
        /* this tick's slice that got past the delay counts toward the
           animation -- and only that slice (the rest was the delay) */
        step = (s->delay < 0) ? -s->delay : 0.0;
        m_write(s, s->from);
    }
    s->t += step;
    if (s->kind == 0) {
        double cycle = s->pingpong ? 2.0 * s->dur : s->dur;
        /* the 1e-9 keeps floating-point accumulation (120 ticks of 1/120 s
           sums to 0.9999999999999989) from leaving a finished tween active */
        if (s->repeat_n >= 0 && s->t >= cycle * s->repeat_n - 1e-9) {
            /* a finished ping-pong has come back to where it started */
            m_write(s, s->pingpong ? s->from : s->to);
            s->active = 0;
            s->running = 0;
            s->finished_ever = 1;
            return;
        }
        double phase_t = fmod(s->t, cycle);
        /* ping-pong: the second half of the cycle runs the eased curve
           backwards.  Phase inside the CURRENT leg (not the clamped whole
           cycle: clamping made the whole return leg snap to 'from' in one
           frame). */
        int rev = s->pingpong && phase_t >= s->dur;
        double pt = rev ? (phase_t - s->dur) : phase_t;
        double p = m_clamp(pt / s->dur, 0.0, 1.0);
        double e = dep_m_ease(s->ease, p);
        double v;
        if (rev)
            v = s->to + (s->from - s->to) * e;      /* reverse leg */
        else
            v = s->from + (s->to - s->from) * e;
        m_write(s, v);
    } else {
        /* semi-implicit Euler, sub-stepped for stability at any framerate */
        int steps = (int)(dt / (1.0 / 240.0)) + 1;
        if (steps > 64) steps = 64;
        double h = dt / steps;
        for (int i = 0; i < steps; i++) {
            double acc = -s->stiffness * (s->value - s->to) - s->damping * s->vel;
            s->vel += acc * h;
            s->value += s->vel * h;
        }
        if (fabs(s->value - s->to) < 0.005 && fabs(s->vel) < 0.02)
            s->settle += dt;
        else
            s->settle = 0;
        m_write(s, s->value);
        if (s->settle > 0.12 || s->t > 30.0) {
            m_write(s, s->to);
            s->active = 0;
            s->running = 0;
            s->finished_ever = 1;
        }
    }
}

/* ================= 3. timelines ================= */

typedef struct {
    int kind;               /* 0 slot step, 1 ui step, 2 wait */
    /* slot step */
    int slot, is_spring, pingpong;
    double to, dur, delay, repeat_n, stiffness, damping;
    double from_override;   /* `starting from N` -- -1/0 = start where it is */
    int has_from;
    char *feel;
    /* ui step */
    int ui_op, dir;
    char *target;
    double x, y, strength;
    int together;
} MStep;

typedef struct {
    char *name;
    MStep *steps;
    int n, cap;
    int *status;            /* 0 idle, 1 running, 2 done (per step) */
    double *start_at;       /* schedule (seconds since play) */
    double tl_time;
    int playing, paused;
    int cur;                /* first not-yet-done step (approx; see tick) */
    double repeat_n;        /* -1 forever */
    int rep, finished;
} MTimeline;

static MTimeline *m_tls = NULL;
static int m_tl_count = 0, m_tl_cap = 0;

static MTimeline *m_tl_find_or_make(const char *name, int make) {
    for (int i = 0; i < m_tl_count; i++)
        if (strcmp(m_tls[i].name, name) == 0) return &m_tls[i];
    if (!make) return NULL;
    if (m_tl_count == m_tl_cap) {
        m_tl_cap = m_tl_cap ? m_tl_cap * 2 : 8;
        m_tls = (MTimeline *)realloc(m_tls, sizeof(MTimeline) * (size_t)m_tl_cap);
        if (!m_tls) dep_die("out of memory");
    }
    MTimeline *t = &m_tls[m_tl_count++];
    memset(t, 0, sizeof *t);
    t->name = m_strdup(name);
    return t;
}

/* freeze / unfreeze the slots of steps already in flight, so pausing a
   timeline pauses the whole scene -- not just the steps that had not
   started yet. */
static void m_tl_freeze_slots(MTimeline *t, int frozen) {
    if (!t) return;
    for (int k = 0; k < t->n; k++) {
        if (t->steps[k].kind != 0) continue;        /* slot steps only */
        if (frozen && t->status[k] != 1) continue;  /* only running ones */
        int sid = t->steps[k].slot;
        if (sid >= 0 && sid < m_slot_cap) m_slots[sid].frozen = frozen;
    }
}

void dep_m_tl_new(const char *name) {
    /* 'make timeline' means a FRESH timeline: if one already exists with
       this name, wipe its steps so re-declaring never duplicates them */
    MTimeline *t = m_tl_find_or_make(name, 1);
    m_tl_freeze_slots(t, 0);
    t->n = 0;
    t->playing = 0;
    t->paused = 0;
    t->finished = 0;
    t->tl_time = 0;
    t->rep = 0;
}

static MStep *m_tl_add_step(const char *name) {
    MTimeline *t = m_tl_find_or_make(name, 1);
    if (t->n == t->cap) {
        t->cap = t->cap ? t->cap * 2 : 8;
        t->steps = (MStep *)realloc(t->steps, sizeof(MStep) * (size_t)t->cap);
        t->status = (int *)realloc(t->status, sizeof(int) * (size_t)t->cap);
        t->start_at = (double *)realloc(t->start_at, sizeof(double) * (size_t)t->cap);
        if (!t->steps || !t->status || !t->start_at) dep_die("out of memory");
    }
    MStep *s = &t->steps[t->n];
    memset(s, 0, sizeof *s);
    t->status[t->n] = 0;
    t->n++;
    return s;
}

void dep_m_tl_add(const char *name, int slot, const char *feel, double to,
                  double dur, double delay, double repeat_n, int pingpong,
                  double stiffness, double damping, int is_spring, int together,
                  double from_override, int has_from) {
    MStep *s = m_tl_add_step(name);
    s->kind = 0;
    s->slot = slot;
    s->is_spring = is_spring;
    s->to = to;
    s->dur = dur > 0.0001 ? dur : 0.0001;
    s->delay = delay > 0 ? delay : 0;
    s->repeat_n = repeat_n;
    s->pingpong = pingpong;
    s->stiffness = stiffness;
    s->damping = damping;
    s->from_override = from_override;
    s->has_from = has_from;
    s->feel = m_strdup(feel && feel[0] ? feel : "smooth");
    s->together = together ? 1 : 0;
}

void dep_m_tl_add_wait(const char *name, double dur, int together) {
    MStep *s = m_tl_add_step(name);
    s->kind = 2;
    s->dur = dur > 0 ? dur : 0;
    s->together = together ? 1 : 0;
}

void dep_m_tl_add_ui(const char *name, int op, const char *target, double dur,
                     const char *feel, int dir, double x, double y,
                     double strength, int together) {
    MStep *s = m_tl_add_step(name);
    s->kind = 1;
    s->ui_op = op;
    s->target = m_strdup(target);
    s->dur = dur;
    s->feel = m_strdup(feel && feel[0] ? feel : "");
    s->dir = dir;
    s->x = x;
    s->y = y;
    s->strength = strength;
    s->together = together ? 1 : 0;
}

/* scheduled length of a step (springs estimate their settle time) */
static double m_step_len(MStep *s) {
    if (s->kind == 2) return s->dur;
    if (s->kind == 1) return s->dur > 0 ? s->dur : 0.4;
    if (s->is_spring) return 1.2;
    double legs = s->pingpong ? 2.0 : 1.0;
    double reps = s->repeat_n < 0 ? 1.0 : (s->repeat_n > 1 ? s->repeat_n : 1.0);
    return s->dur * legs * reps;
}

static void m_tl_schedule(MTimeline *t) {
    for (int k = 0; k < t->n; k++) {
        if (k == 0) t->start_at[0] = t->steps[0].delay;
        else {
            double base = t->steps[k].together ? t->start_at[k - 1]
                                               : t->start_at[k - 1] + m_step_len(&t->steps[k - 1]);
            t->start_at[k] = base + t->steps[k].delay;
        }
    }
}

void dep_m_tl_play(const char *name, double repeat_n) {
    MTimeline *t = m_tl_find_or_make(name, 1);
    if (repeat_n <= 0 && repeat_n != -1) repeat_n = 1;
    t->repeat_n = repeat_n;
    t->playing = 1;
    t->paused = 0;
    m_tl_freeze_slots(t, 0);
    t->tl_time = 0;
    t->rep = 0;
    t->finished = 0;
    for (int k = 0; k < t->n; k++) t->status[k] = 0;
    m_tl_schedule(t);
}

void dep_m_tl_pause(const char *name) {
    MTimeline *t = m_tl_find_or_make(name, 0);
    if (!t || t->paused) return;
    t->paused = 1;
    m_tl_freeze_slots(t, 1);
}

void dep_m_tl_resume(const char *name) {
    MTimeline *t = m_tl_find_or_make(name, 0);
    if (!t) return;
    t->paused = 0;
    m_tl_freeze_slots(t, 0);
}

void dep_m_tl_stop(const char *name) {
    MTimeline *t = m_tl_find_or_make(name, 0);
    if (!t) return;
    t->playing = 0;
    t->paused = 0;
    t->finished = 0;
    m_tl_freeze_slots(t, 0);
    for (int k = 0; k < t->n; k++) t->status[k] = 0;
}

int dep_m_tl_playing(const char *name) {
    MTimeline *t = m_tl_find_or_make(name, 0);
    return t ? (t->playing && !t->paused) : 0;
}

int dep_m_tl_finished(const char *name) {
    MTimeline *t = m_tl_find_or_make(name, 0);
    return t ? t->finished : 0;
}

double dep_m_tl_playing_v(DEPValue name) {
    const char *s = (name.tag == DEP_T_TEXT) ? name.as.s->chars : "";
    int r = dep_m_tl_playing(s);
    dep_release(name);
    return (double)r;
}

double dep_m_tl_finished_v(DEPValue name) {
    const char *s = (name.tag == DEP_T_TEXT) ? name.as.s->chars : "";
    int r = dep_m_tl_finished(s);
    dep_release(name);
    return (double)r;
}

static int m_step_done(MTimeline *t, int k) {
    MStep *s = &t->steps[k];
    if (s->kind == 2) return t->tl_time >= t->start_at[k] + s->dur;
    if (s->kind == 1) return !dep_m_ui_busy(s->target);
    return t->status[k] == 1 && !dep_m_active(s->slot);
}

static void m_tl_tick(MTimeline *t, double dt) {
    (void)dt;
    if (!t->playing || t->paused) return;
    t->tl_time += dt;
    int all_done = 1;
    for (int k = 0; k < t->n; k++) {
        MStep *s = &t->steps[k];
        if (t->status[k] == 2) continue;
        all_done = 0;
        if (t->status[k] == 0) {
            int ok = 1;
            if (k > 0)
                ok = s->together ? (t->status[k - 1] >= 1) : (t->status[k - 1] == 2);
            if (!ok) break;
            if (t->tl_time < t->start_at[k]) break;
            /* start the step */
            if (s->kind == 0) {
                if (s->is_spring)
                    dep_m_spring(s->slot, s->to, s->stiffness, s->damping);
                else
                    dep_m_move(s->slot, s->feel, s->to, s->dur, 0,
                               s->repeat_n, s->pingpong,
                               s->from_override, s->has_from);
            } else if (s->kind == 1) {
                if (m_ui_exec_hook)
                    m_ui_exec_hook(s->ui_op, s->target, s->dur, s->feel,
                                   s->dir, s->x, s->y, s->strength);
            }
            t->status[k] = 1;
        }
        if (t->status[k] == 1 && m_step_done(t, k)) {
            t->status[k] = 2;
            continue;
        }
        if (t->status[k] == 1 && !(k + 1 < t->n && t->steps[k + 1].together))
            break;
    }
    if (!all_done) {
        /* check again: everything may have finished this tick */
        all_done = 1;
        for (int k = 0; k < t->n; k++)
            if (t->status[k] != 2) { all_done = 0; break; }
    }
    if (all_done && t->n > 0) {
        t->rep++;
        if (t->repeat_n < 0 || (double)t->rep < t->repeat_n) {
            for (int k = 0; k < t->n; k++) t->status[k] = 0;
            t->tl_time = 0;
        } else {
            t->playing = 0;
            t->finished = 1;
        }
    }
}

/* ================= 4. UI motion ================= */

typedef struct MUI {
    char name[128];
    int op;
    double t, dur;
    int ease, dir;
    double x, y, strength;      /* op payload */
    double from_dx, from_dy;
    double dx, dy, alpha, scale;
    int hidden, active;
    struct MUI *next;
} MUI;

static MUI *m_uis = NULL;

void dep_m_set_ui_exec(void (*fn)(int, const char *, double, const char *,
                                  int, double, double, double)) {
    m_ui_exec_hook = fn;
}

static MUI *m_ui_find(const char *name, int make) {
    for (MUI *u = m_uis; u; u = u->next)
        if (strcmp(u->name, name) == 0) return u;
    if (!make) return NULL;
    MUI *u = (MUI *)calloc(1, sizeof(MUI));
    if (!u) dep_die("out of memory");
    snprintf(u->name, sizeof u->name, "%s", name);
    u->alpha = 1.0;
    u->scale = 1.0;
    u->next = m_uis;
    m_uis = u;
    return u;
}

int dep_m_ui_busy(const char *name) {
    MUI *u = m_ui_find(name, 0);
    return u ? u->active : 0;
}

void dep_m_ui_exec(int op, const char *name, double dur, const char *feel,
                   int dir, double x, double y, double strength) {
    if (!name || !name[0]) return;
    MUI *u = m_ui_find(name, 1);
    double def_dur = 0.4;
    int def_ease = DEP_EASE_CUBIC_INOUT;
    switch (op) {
    case DEP_UI_POP_IN:   def_ease = DEP_EASE_BACK_OUT;  break;
    case DEP_UI_POP_OUT:  def_ease = DEP_EASE_CUBIC_IN;  def_dur = 0.35; break;
    case DEP_UI_FADE_IN:  def_ease = DEP_EASE_SINE_INOUT; break;
    case DEP_UI_FADE_OUT: def_ease = DEP_EASE_SINE_INOUT; break;
    case DEP_UI_SLIDE_IN: def_ease = DEP_EASE_CUBIC_OUT; def_dur = 0.45; break;
    case DEP_UI_SLIDE_OUT: def_ease = DEP_EASE_CUBIC_IN; def_dur = 0.45; break;
    case DEP_UI_SHAKE:    def_ease = DEP_EASE_LINEAR;    break;
    case DEP_UI_BUMP:     def_ease = DEP_EASE_LINEAR;    def_dur = 0.22; break;
    case DEP_UI_GLIDE:    def_dur = 0.5; break;
    default: break;
    }
    u->op = op;
    u->t = 0;
    u->dur = dur > 0.001 ? dur : def_dur;
    u->ease = DEP_EASE_CUBIC_INOUT;
    if (feel && feel[0]) {
        int e = dep_m_ease_id(feel);
        if (e < 0)
            dep_die("I don't know the feeling \"%s\" "
                    "(try bouncy, springy, snappy, smooth, quick...)", feel);
        u->ease = e;
    } else {
        u->ease = def_ease;
    }
    u->dir = dir;
    u->x = x;
    u->y = y;
    u->strength = strength > 0 ? strength : 6.0;
    u->active = 1;
    u->from_dx = u->dx;
    u->from_dy = u->dy;
    if (op == DEP_UI_POP_IN || op == DEP_UI_FADE_IN || op == DEP_UI_SLIDE_IN) {
        u->hidden = 0;
        if (op == DEP_UI_POP_IN) u->scale = 0;
        if (op == DEP_UI_SLIDE_IN && u->alpha < 1) u->alpha = 0;
    }
    if (op == DEP_UI_GLIDE) { u->x = x; u->y = y; }
}

int dep_m_ui_state(const char *name, double *dx, double *dy,
                   double *alpha, double *scale, int *hidden) {
    MUI *u = m_ui_find(name, 0);
    if (!u) {
        *dx = 0; *dy = 0; *alpha = 1; *scale = 1; *hidden = 0;
        return 0;
    }
    *dx = u->dx; *dy = u->dy; *alpha = u->alpha;
    *scale = u->scale; *hidden = u->hidden;
    return u->active;
}

static void m_ui_tick(double dt) {
    for (MUI *u = m_uis; u; u = u->next) {
        if (!u->active) continue;
        u->t += dt;
        double p = m_clamp(u->t / u->dur, 0.0, 1.0);
        double e = dep_m_ease(u->ease, p);
        switch (u->op) {
        case DEP_UI_POP_IN:
            u->scale = e;
            u->alpha = m_clamp(p * 2.5, 0, 1);
            if (p >= 1) { u->scale = 1; u->alpha = 1; }
            break;
        case DEP_UI_POP_OUT:
            u->scale = 1.0 - e;
            u->alpha = 1.0 - p;
            if (p >= 1) { u->scale = 0; u->alpha = 0; }
            break;
        case DEP_UI_FADE_IN:
            u->alpha = e;
            if (p >= 1) u->alpha = 1;
            break;
        case DEP_UI_FADE_OUT:
            u->alpha = 1.0 - e;
            if (p >= 1) u->alpha = 0;
            break;
        case DEP_UI_SLIDE_IN: {
            double dist = u->x;                     /* passed by the app kit */
            double k = 1.0 - e;
            if (u->dir == 0) u->dx = -dist * k;
            else if (u->dir == 1) u->dx = dist * k;
            else if (u->dir == 2) u->dy = -dist * k;
            else u->dy = dist * k;
            u->alpha = m_clamp(p * 2.0, 0, 1);
            if (p >= 1) {
                u->dx = 0; u->dy = 0; u->alpha = 1;
            }
            break;
        }
        case DEP_UI_SLIDE_OUT: {
            double dist = u->x;
            if (u->dir == 0) u->dx = -dist * e;
            else if (u->dir == 1) u->dx = dist * e;
            else if (u->dir == 2) u->dy = -dist * e;
            else u->dy = dist * e;
            if (p >= 1) u->hidden = 1;
            break;
        }
        case DEP_UI_SHAKE:
            u->dx = u->strength * (1.0 - p) * sin(u->t * 50.0);
            if (p >= 1) u->dx = 0;
            break;
        case DEP_UI_BUMP:
            u->scale = 1.0 + 0.22 * sin(M_PI * p);
            if (p >= 1) u->scale = 1;
            break;
        case DEP_UI_GLIDE:
            u->dx = u->from_dx + (u->x - u->from_dx) * e;
            u->dy = u->from_dy + (u->y - u->from_dy) * e;
            if (p >= 1) { u->dx = u->x; u->dy = u->y; }
            break;
        }
        if (p >= 1) u->active = 0;
    }
}

/* ================= 5. screen fx ================= */

static struct { double strength, dur, t; int active; } m_fx_shake;
static struct { double r, g, b, dur, t; int active; } m_fx_flash;
static struct { double r, g, b, dur, t; int mode; } m_fx_fade;   /* 1 to, 2 from */
static struct { double from, to, dur, t, cur; int ease, active; } m_fx_zoom =
    { 0, 0, 0, 0, 1.0, 0, 0 };          /* cur starts at 1 (no zoom) */

void dep_m_shake(double strength, double dur) {
    m_fx_shake.strength = strength;
    m_fx_shake.dur = dur > 0.01 ? dur : 0.01;
    m_fx_shake.t = 0;
    m_fx_shake.active = 1;
}

void dep_m_flash(double r, double g, double b, double dur) {
    m_fx_flash.r = r; m_fx_flash.g = g; m_fx_flash.b = b;
    m_fx_flash.dur = dur > 0.01 ? dur : 0.01;
    m_fx_flash.t = 0;
    m_fx_flash.active = 1;
}

void dep_m_fade_to(double r, double g, double b, double dur) {
    m_fx_fade.r = r; m_fx_fade.g = g; m_fx_fade.b = b;
    m_fx_fade.dur = dur > 0.01 ? dur : 0.01;
    m_fx_fade.t = 0;
    m_fx_fade.mode = 1;
}

void dep_m_fade_from(double r, double g, double b, double dur) {
    m_fx_fade.r = r; m_fx_fade.g = g; m_fx_fade.b = b;
    m_fx_fade.dur = dur > 0.01 ? dur : 0.01;
    m_fx_fade.t = 0;
    m_fx_fade.mode = 2;
}

void dep_m_zoom(double target, double dur, const char *feel) {
    m_fx_zoom.from = m_fx_zoom.cur;
    m_fx_zoom.to = target;
    m_fx_zoom.dur = dur > 0.01 ? dur : 0.01;
    m_fx_zoom.t = 0;
    int e = dep_m_ease_id(feel);
    m_fx_zoom.ease = e >= 0 ? e : DEP_EASE_CUBIC_INOUT;
    m_fx_zoom.active = 1;
}

void dep_m_reset_screen(void) {
    m_fx_shake.active = 0;
    m_fx_flash.active = 0;
    m_fx_fade.mode = 0;
    m_fx_zoom.active = 0;
    m_fx_zoom.cur = 1.0;
}

int dep_m_camera(double *ox, double *oy, double *zoom) {
    double sx = 0, sy = 0;
    if (m_fx_shake.active) {
        double k = 1.0 - m_fx_shake.t / m_fx_shake.dur;
        if (k < 0) k = 0;
        double mag = m_fx_shake.strength * k * k;
        sx = mag * sin(m_fx_shake.t * 57.3);
        sy = mag * 0.8 * cos(m_fx_shake.t * 49.7);
    }
    *ox = sx;
    *oy = sy;
    *zoom = m_fx_zoom.cur;
    return (fabs(sx) + fabs(sy) > 0.01) || fabs(m_fx_zoom.cur - 1.0) > 0.0005;
}

int dep_m_overlay(double *r, double *g, double *b, double *a) {
    if (m_fx_flash.active) {
        *r = m_fx_flash.r; *g = m_fx_flash.g; *b = m_fx_flash.b;
        *a = m_clamp(1.0 - m_fx_flash.t / m_fx_flash.dur, 0, 1);
        return 1;
    }
    if (m_fx_fade.mode == 1) {
        *r = m_fx_fade.r; *g = m_fx_fade.g; *b = m_fx_fade.b;
        *a = m_clamp(m_fx_fade.t / m_fx_fade.dur, 0, 1);
        return 1;
    }
    if (m_fx_fade.mode == 2) {
        *r = m_fx_fade.r; *g = m_fx_fade.g; *b = m_fx_fade.b;
        *a = m_clamp(1.0 - m_fx_fade.t / m_fx_fade.dur, 0, 1);
        return 1;
    }
    return 0;
}

/* ================= 6. particles ================= */

#define M_MAX_PARTICLES 8192

typedef struct {
    float x, y, vx, vy, life, maxlife, size;
    float r, g, b, a, rot, vrot, grav, drag, flut, phase;
    int kind;
} MParticle;

static MParticle m_parts[M_MAX_PARTICLES];
static long m_part_count = 0;
static double m_screen_w = 800, m_screen_h = 600;

static struct {
    int active;
    double rate, acc, speed, size, life;
    float col[4];
    int has_col;
} m_emit_rain, m_emit_snow;

int dep_m_particle_kind(const char *word) {
    if (!word) return -1;
    if (strcmp(word, "sparks") == 0)   return DEP_PK_SPARK;
    if (strcmp(word, "confetti") == 0) return DEP_PK_CONFETTI;
    if (strcmp(word, "smoke") == 0)    return DEP_PK_SMOKE;
    if (strcmp(word, "stars") == 0)    return DEP_PK_STAR;
    if (strcmp(word, "fire") == 0)     return DEP_PK_FIRE;
    if (strcmp(word, "bubbles") == 0)  return DEP_PK_BUBBLE;
    if (strcmp(word, "hearts") == 0)   return DEP_PK_HEART;
    if (strcmp(word, "rain") == 0)     return DEP_PK_RAIN;
    if (strcmp(word, "snow") == 0)     return DEP_PK_SNOW;
    if (strcmp(word, "particles") == 0) return DEP_PK_CUSTOM;
    return -1;
}

static MParticle *m_spawn(void) {
    if (m_part_count >= M_MAX_PARTICLES) return NULL;
    MParticle *p = &m_parts[m_part_count++];
    memset(p, 0, sizeof *p);
    p->a = 1;
    return p;
}

static const float M_CONFETTI_COLS[10][3] = {
    {0.902f, 0.224f, 0.275f}, {0.914f, 0.769f, 0.416f}, {0.165f, 0.616f, 0.561f},
    {0.427f, 0.349f, 0.478f}, {0.529f, 0.808f, 0.922f}, {0.616f, 0.98f, 0.498f},
    {0.71f, 0.89f, 0.549f}, {1.0f, 0.82f, 0.44f}, {0.980f, 0.549f, 0.639f},
    {0.561f, 0.816f, 0.855f}
};

static void m_spawn_kind(int kind, double x, double y, const float *col,
                         double spd, double size, double life) {
    MParticle *p = m_spawn();
    if (!p) return;
    p->kind = kind;
    p->x = (float)x;
    p->y = (float)y;
    p->phase = (float)(m_rand() * M_PI * 2.0);
    double lm = life > 0 ? life : 1.0;
    double sm = size > 0 ? size : 1.0;
    double vm = spd > 0 ? spd : 1.0;
    switch (kind) {
    case DEP_PK_SPARK: {
        double ang = m_rand() * M_PI * 2.0;
        double v = m_rand_range(120, 330) * vm;
        p->vx = (float)(cos(ang) * v);
        p->vy = (float)(sin(ang) * v);
        p->grav = 260; p->drag = 1.4f;
        p->life = p->maxlife = (float)(m_rand_range(0.35, 0.9) * lm);
        p->size = (float)(m_rand_range(1.8, 3.6) * sm);
        if (col) { p->r = col[0]; p->g = col[1]; p->b = col[2]; }
        else {
            double w = m_rand();
            if (w < 0.4)      { p->r = 0.976f; p->g = 0.769f; p->b = 0.180f; }
            else if (w < 0.7) { p->r = 0.914f; p->g = 0.769f; p->b = 0.416f; }
            else if (w < 0.9) { p->r = 0.969f; p->g = 0.494f; p->b = 0.275f; }
            else              { p->r = 1.0f;   p->g = 0.984f; p->b = 0.902f; }
        }
        break;
    }
    case DEP_PK_CONFETTI: {
        double ang = -M_PI / 2.0 + m_rand_range(-1.3, 1.3);
        double v = m_rand_range(120, 300) * vm;
        p->vx = (float)(cos(ang) * v);
        p->vy = (float)(sin(ang) * v);
        p->grav = 170; p->drag = 0.5f; p->flut = 55;
        p->life = p->maxlife = (float)(m_rand_range(1.1, 2.3) * lm);
        p->size = (float)(m_rand_range(3, 5.5) * sm);
        p->rot = (float)(m_rand() * 360.0);
        p->vrot = (float)m_rand_range(-320, 320);
        if (col) { p->r = col[0]; p->g = col[1]; p->b = col[2]; }
        else {
            int i = (int)(m_rand() * 10.0) % 10;
            p->r = M_CONFETTI_COLS[i][0];
            p->g = M_CONFETTI_COLS[i][1];
            p->b = M_CONFETTI_COLS[i][2];
        }
        break;
    }
    case DEP_PK_SMOKE: {
        double ang = -M_PI / 2.0 + m_rand_range(-0.5, 0.5);
        double v = m_rand_range(12, 45) * vm;
        p->vx = (float)(cos(ang) * v);
        p->vy = (float)(sin(ang) * v);
        p->grav = -18; p->drag = 0.6f;
        p->life = p->maxlife = (float)(m_rand_range(1.4, 2.8) * lm);
        p->size = (float)(m_rand_range(5, 9) * sm);
        double g = m_rand_range(0.32, 0.62);
        if (col) { p->r = col[0]; p->g = col[1]; p->b = col[2]; }
        else { p->r = (float)g; p->g = (float)g; p->b = (float)g; }
        p->a = 0.55f;
        break;
    }
    case DEP_PK_STAR: {
        double ang = m_rand() * M_PI * 2.0;
        double v = m_rand_range(40, 170) * vm;
        p->vx = (float)(cos(ang) * v);
        p->vy = (float)(sin(ang) * v);
        p->grav = 55; p->drag = 1.0f;
        p->life = p->maxlife = (float)(m_rand_range(0.7, 1.6) * lm);
        p->size = (float)(m_rand_range(2, 4) * sm);
        p->rot = (float)(m_rand() * 90.0);
        p->vrot = (float)m_rand_range(-60, 60);
        if (col) { p->r = col[0]; p->g = col[1]; p->b = col[2]; }
        else {
            double w = m_rand();
            if (w < 0.5) { p->r = 1.0f; p->g = 0.95f; p->b = 0.75f; }
            else         { p->r = 1.0f; p->g = 1.0f; p->b = 1.0f; }
        }
        break;
    }
    case DEP_PK_FIRE: {
        double ang = -M_PI / 2.0 + m_rand_range(-0.55, 0.55);
        double v = m_rand_range(25, 110) * vm;
        p->vx = (float)(cos(ang) * v);
        p->vy = (float)(sin(ang) * v);
        p->grav = -140; p->drag = 1.1f;
        p->life = p->maxlife = (float)(m_rand_range(0.35, 0.85) * lm);
        p->size = (float)(m_rand_range(4.5, 9) * sm);
        p->r = 1.0f; p->g = 0.82f; p->b = 0.25f;
        if (col) { p->r = col[0]; p->g = col[1]; p->b = col[2]; }
        break;
    }
    case DEP_PK_BUBBLE: {
        double v = m_rand_range(20, 60) * vm;
        p->vx = (float)m_rand_range(-8, 8);
        p->vy = (float)(-v);
        p->grav = -50; p->drag = 0.2f; p->flut = 26;
        p->life = p->maxlife = (float)(m_rand_range(1.0, 2.6) * lm);
        p->size = (float)(m_rand_range(2, 6) * sm);
        if (col) { p->r = col[0]; p->g = col[1]; p->b = col[2]; }
        else { p->r = 0.65f; p->g = 0.85f; p->b = 0.95f; }
        p->a = 0.7f;
        break;
    }
    case DEP_PK_HEART: {
        double ang = -M_PI / 2.0 + m_rand_range(-0.9, 0.9);
        double v = m_rand_range(60, 190) * vm;
        p->vx = (float)(cos(ang) * v);
        p->vy = (float)(sin(ang) * v);
        p->grav = -35; p->drag = 0.8f; p->flut = 30;
        p->life = p->maxlife = (float)(m_rand_range(0.8, 1.6) * lm);
        p->size = (float)(m_rand_range(4, 7) * sm);
        if (col) { p->r = col[0]; p->g = col[1]; p->b = col[2]; }
        else if (m_rand() < 0.5) { p->r = 0.957f; p->g = 0.263f; p->b = 0.365f; }
        else { p->r = 1.0f; p->g = 0.561f; p->b = 0.639f; }
        break;
    }
    case DEP_PK_RAIN: {
        double v = m_rand_range(430, 580) * vm;
        p->vx = (float)(-v * 0.08);
        p->vy = (float)v;
        /* an explicit `life N` wins; else the drop dies when it lands */
        p->life = p->maxlife = (float)(life > 0 ? life
                                       : (m_screen_h + 40.0) / v);
        p->size = (float)(m_rand_range(10, 16) * (size > 0 ? size : 1.0));
        if (col) { p->r = col[0]; p->g = col[1]; p->b = col[2]; }
        else { p->r = 0.537f; p->g = 0.762f; p->b = 0.851f; }
        p->a = 0.62f;
        break;
    }
    case DEP_PK_SNOW: {
        double v = m_rand_range(40, 95) * vm;
        p->vx = 0;
        p->vy = (float)v;
        p->flut = 22;
        p->life = p->maxlife = (float)(life > 0 ? life
                                       : (m_screen_h + 40.0) / v);
        p->size = (float)(m_rand_range(1.6, 3.4) * (size > 0 ? size : 1.0));
        if (col) { p->r = col[0]; p->g = col[1]; p->b = col[2]; }
        else { p->r = 1.0f; p->g = 1.0f; p->b = 1.0f; }
        p->a = 0.9f;
        break;
    }
    default: {  /* DEP_PK_CUSTOM */
        double ang = m_rand() * M_PI * 2.0;
        double v = m_rand_range(60, 250) * vm;
        p->vx = (float)(cos(ang) * v);
        p->vy = (float)(sin(ang) * v);
        p->grav = 160; p->drag = 1.0f;
        p->life = p->maxlife = (float)(m_rand_range(0.6, 1.4) * lm);
        p->size = (float)(m_rand_range(2, 4) * sm);
        if (col) { p->r = col[0]; p->g = col[1]; p->b = col[2]; }
        else { p->r = 1.0f; p->g = 1.0f; p->b = 1.0f; }
        break;
    }
    }
}

void dep_m_burst(int kind, double n, double x, double y,
                 const float *col, double speed, double size, double life) {
    if (kind == DEP_PK_RAIN || kind == DEP_PK_SNOW) {
        /* bursting rain/snow = a one-shot shower across the top of the screen */
        long count = (long)m_clamp(n, 1, 4096);
        for (long i = 0; i < count; i++)
            m_spawn_kind(kind, m_rand_range(0, m_screen_w),
                         m_rand_range(-m_screen_h * 0.6, -6.0),
                         col, speed, size, life);
        return;
    }
    long count = (long)m_clamp(n, 1, 4096);
    for (long i = 0; i < count; i++)
        m_spawn_kind(kind, x, y, col, speed, size, life);
}

void dep_m_rain(double rate, const float *col, double speed, double size,
                double life) {
    m_emit_rain.active = rate > 0;
    m_emit_rain.rate = rate;
    m_emit_rain.acc = 0;
    m_emit_rain.speed = speed;
    m_emit_rain.size = size;
    m_emit_rain.life = life;          /* <= 0: lifetime from fall height */
    m_emit_rain.has_col = col ? 1 : 0;
    if (col) memcpy(m_emit_rain.col, col, sizeof(float) * 4);
}

void dep_m_snow(double rate, const float *col, double speed, double size,
                double life) {
    m_emit_snow.active = rate > 0;
    m_emit_snow.rate = rate;
    m_emit_snow.acc = 0;
    m_emit_snow.speed = speed;
    m_emit_snow.size = size;
    m_emit_snow.life = life;
    m_emit_snow.has_col = col ? 1 : 0;
    if (col) memcpy(m_emit_snow.col, col, sizeof(float) * 4);
}

void dep_m_clear_particles(void) {
    m_part_count = 0;
    m_emit_rain.active = 0;
    m_emit_snow.active = 0;
}

long dep_m_particle_count(void) { return m_part_count; }

double dep_m_particle_count_v(void) { return (double)dep_m_particle_count(); }

double dep_m_moving_v(DEPValue target) {
    dep_release(target);
    dep_die("'moving' needs a target like dot.x -- the compiler resolves it "
            "from a 'move dot.x toward ...' sentence");
    return 0;
}

int dep_m_particle_at(long i, MParticleView *out) {
    if (i < 0 || i >= m_part_count) return 0;
    MParticle *p = &m_parts[i];
    out->x = p->x; out->y = p->y; out->vx = p->vx; out->vy = p->vy;
    out->life = p->life; out->maxlife = p->maxlife; out->size = p->size;
    out->r = p->r; out->g = p->g; out->b = p->b; out->a = p->a;
    out->rot = p->rot; out->grav = p->grav; out->flut = p->flut;
    out->phase = p->phase;
    out->kind = p->kind;
    return 1;
}

/* uniform particle physics + emitter stepping */
static void m_particles_tick(double dt) {
    /* continuous emitters */
    if (m_emit_rain.active) {
        m_emit_rain.acc += m_emit_rain.rate * dt;
        int guard = 0;
        while (m_emit_rain.acc >= 1.0 && guard++ < 96) {
            m_emit_rain.acc -= 1.0;
            m_spawn_kind(DEP_PK_RAIN, m_rand_range(0, m_screen_w), -12.0,
                         m_emit_rain.has_col ? m_emit_rain.col : NULL,
                         m_emit_rain.speed, m_emit_rain.size,
                         m_emit_rain.life);
        }
    }
    if (m_emit_snow.active) {
        m_emit_snow.acc += m_emit_snow.rate * dt;
        int guard = 0;
        while (m_emit_snow.acc >= 1.0 && guard++ < 96) {
            m_emit_snow.acc -= 1.0;
            m_spawn_kind(DEP_PK_SNOW, m_rand_range(0, m_screen_w), -8.0,
                         m_emit_snow.has_col ? m_emit_snow.col : NULL,
                         m_emit_snow.speed, m_emit_snow.size,
                         m_emit_snow.life);
        }
    }
    /* physics */
    for (long i = 0; i < m_part_count; i++) {
        MParticle *p = &m_parts[i];
        p->life -= (float)dt;
        if (p->life <= 0) {
            m_parts[i] = m_parts[m_part_count - 1];
            m_part_count--;
            i--;
            continue;
        }
        double t = p->maxlife > 0 ? (double)(p->maxlife - p->life) : 0;
        if (p->flut)
            p->vx += (float)(sin(t * 7.0 + p->phase) * p->flut * dt);
        if (p->drag) {
            float k = (float)(1.0 - p->drag * dt);
            if (k < 0) k = 0;
            p->vx *= k; p->vy *= k;
        }
        p->vy += p->grav * (float)dt;
        p->x += p->vx * (float)dt;
        p->y += p->vy * (float)dt;
        if (p->vrot) p->rot += p->vrot * (float)dt;
        if ((p->kind == DEP_PK_RAIN || p->kind == DEP_PK_SNOW) &&
            p->y > m_screen_h + 20.0f) {
            m_parts[i] = m_parts[m_part_count - 1];
            m_part_count--;
            i--;
        }
    }
}

/* ================= 7. clock ================= */

void dep_m_set_screen(double w, double h) {
    if (w > 0) m_screen_w = w;
    if (h > 0) m_screen_h = h;
}

void dep_motion_tick(double dt) {
    if (dt <= 0) return;
    if (dt > 0.1) dt = 0.1;
    /* fx clocks */
    if (m_fx_shake.active) {
        m_fx_shake.t += dt;
        if (m_fx_shake.t >= m_fx_shake.dur) m_fx_shake.active = 0;
    }
    if (m_fx_flash.active) {
        m_fx_flash.t += dt;
        if (m_fx_flash.t >= m_fx_flash.dur) m_fx_flash.active = 0;
    }
    if (m_fx_fade.mode) {
        m_fx_fade.t += dt;
        if (m_fx_fade.mode == 2 && m_fx_fade.t >= m_fx_fade.dur)
            m_fx_fade.mode = 0;
    }
    if (m_fx_zoom.active) {
        m_fx_zoom.t += dt;
        double p = m_clamp(m_fx_zoom.t / m_fx_zoom.dur, 0, 1);
        m_fx_zoom.cur = m_fx_zoom.from +
                        (m_fx_zoom.to - m_fx_zoom.from) * dep_m_ease(m_fx_zoom.ease, p);
        if (p >= 1) { m_fx_zoom.cur = m_fx_zoom.to; m_fx_zoom.active = 0; }
    }
    /* timelines start steps, then slots advance (writes land in variables) */
    for (int i = 0; i < m_tl_count; i++) m_tl_tick(&m_tls[i], dt);
    for (int i = 0; i < m_slot_count; i++) m_slot_tick(&m_slots[i], dt);
    m_ui_tick(dt);
    m_particles_tick(dt);
}

void dep_motion_advance(double seconds) {
    if (seconds <= 0) return;
    if (seconds > 3600) seconds = 3600;
    int steps = (int)ceil(seconds / (1.0 / 120.0));
    if (steps < 1) steps = 1;
    if (steps > 28800) steps = 28800;
    double h = seconds / steps;
    for (int i = 0; i < steps; i++)
        dep_motion_tick(h);
}

void dep_m_stop_all(void) {
    for (int i = 0; i < m_slot_count; i++) dep_m_stop(i);
    for (int i = 0; i < m_tl_count; i++) dep_m_tl_stop(m_tls[i].name);
    for (MUI *u = m_uis; u; u = u->next) {
        u->active = 0;
        u->dx = 0;
        u->dy = 0;
        if (u->op != DEP_UI_POP_OUT && u->op != DEP_UI_SLIDE_OUT &&
            u->op != DEP_UI_FADE_OUT)
            u->hidden = 0;
    }
    m_fx_shake.active = 0;
    m_fx_flash.active = 0;
    m_fx_fade.mode = 0;
    m_fx_zoom.active = 0;
    m_fx_zoom.cur = 1.0;
    dep_m_clear_particles();
}

/* ================= 8. engine self-test ================= */

static double st_from_1(void) { return 10.0; }
static double st_val_1 = 0;
static void st_write_1(double v) { st_val_1 = v; }
static double st_from_2(void) { return 0.0; }
static double st_val_2 = 0;
static void st_write_2(double v) { st_val_2 = v; }
static double st_val_3 = 0;
static void st_write_3(double v) { st_val_3 = v; }

int dep_motion_selftest(void) {
    int ok = 1;
    /* easing bounds */
    for (int c = 0; c <= DEP_EASE_BOUNCE_INOUT; c++) {
        double a = dep_m_ease(c, 0.0), b = dep_m_ease(c, 1.0);
        if (fabs(a) > 0.01 || fabs(b - 1.0) > 0.01) ok = 0;
    }
    /* tween reaches its target and writes through the binding */
    dep_m_bind(900, st_from_1, st_write_1);
    dep_m_move(900, "linear", 110.0, 1.0, 0, 0, 0, 0, 0);
    dep_motion_advance(1.0);
    if (fabs(st_val_1 - 110.0) > 0.01) ok = 0;
    if (dep_m_active(900)) ok = 0;
    /* spring settles near its target */
    dep_m_bind(901, st_from_2, st_write_2);
    dep_m_spring(901, 42.0, 170, 26);
    dep_motion_advance(6.0);
    if (fabs(st_val_2 - 42.0) > 0.05) ok = 0;
    /* timeline sequencing */
    st_val_3 = 0;
    dep_m_bind(902, st_from_1, st_write_1);
    dep_m_bind(903, st_from_2, st_write_3);
    dep_m_tl_new("selftest");
    dep_m_tl_add("selftest", 902, "linear", 50.0, 0.5, 0, 0, 0, -1, -1, 0, 0,
                 0, 0);
    dep_m_tl_add("selftest", 903, "linear", 80.0, 0.5, 0, 0, 0, -1, -1, 0, 0,
                 0, 0);
    dep_m_tl_play("selftest", 1);
    dep_motion_advance(0.2);
    if (fabs(st_val_3 - 0.0) > 0.01) ok = 0;       /* step 2 must not start */
    dep_motion_advance(0.9);
    if (fabs(st_val_3 - 80.0) > 0.01) ok = 0;      /* step 2 done */
    if (dep_m_tl_playing("selftest")) ok = 0;
    if (!dep_m_tl_finished("selftest")) ok = 0;
    /* cleanup */
    dep_m_stop(900); dep_m_stop(901); dep_m_stop(902); dep_m_stop(903);
    dep_m_tl_stop("selftest");
    return ok;
}

