@echo off
title DeadEnd
setlocal EnableExtensions

rem ------------------------------------------------------------------
rem  DeadEnd CLI launcher (Windows)
rem  - finds a Python for you: bundled, then py -3, python, python3
rem  - never changes the current directory, so relative program paths
rem    behave the way you expect:
rem        D:\repo> dec run examples\pong.dep
rem        D:\repo\examples> dec pong.dep
rem    Both run THIS folder's compiler, whichever directory you call
rem    it from (a stray older `dec` on PATH cannot shadow the sources).
rem  - keeps the window open on double-click so any error text
rem    stays readable and copyable (right-click -^> Select All -^> Enter)
rem  - exits with the same code dec.py produced
rem ------------------------------------------------------------------

rem -- were we started by a double-click? (then pause at the end) --
set "DBLCLK=0"
echo(%cmdcmdline% | findstr /i /c:"%~f0" >nul 2>&1
if not errorlevel 1 set "DBLCLK=1"

rem -- guard: launched straight from inside the ZIP viewer --
if exist "%~dp0src\dec.py" goto :findpy
echo(
echo  DeadEnd cannot find src\dec.py next to this file.
echo(
echo  This happens when you double-click dec.bat straight inside the
echo  ZIP window: Windows only unpacks this one .bat to a temp folder.
echo(
echo  Fix: right-click the ZIP, choose "Extract All...", open the
echo  extracted folder, then run dec.bat or install.bat from there.
echo(
if "%DBLCLK%"=="1" pause
exit /b 1

:findpy
set "PYEXE="
if exist "%~dp0tools\python\python.exe" set "PYEXE=%~dp0tools\python\python.exe"
if defined PYEXE goto :havepy

py -3 -c "print(1)" >nul 2>&1
if not errorlevel 1 set "PYEXE=py -3"
if defined PYEXE goto :havepy

python -c "print(1)" >nul 2>&1
if not errorlevel 1 set "PYEXE=python"
if defined PYEXE goto :havepy

python3 -c "print(1)" >nul 2>&1
if not errorlevel 1 set "PYEXE=python3"
if defined PYEXE goto :havepy

goto :nopython

:havepy
%PYEXE% "%~dp0src\dec.py" %*
set "EC=%errorlevel%"
if "%DBLCLK%"=="0" exit /b %EC%
echo(
echo  [DeadEnd] finished -- exit code %EC%. Press any key to close.
pause >nul
exit /b %EC%

:nopython
echo(
echo  ==================================================================
echo   DeadEnd needs Python 3 (version 3.8 or newer) -- not found.
echo   Nothing was broken, it just is not installed yet. To fix:
echo(
echo     1. Go to   https://www.python.org/downloads/
echo     2. Download Python 3 and run the installer.
echo     3. IMPORTANT: on the first installer screen, tick the box
echo        "Add python.exe to PATH" before clicking Install Now.
echo     4. Run install.bat again -- it will finish the setup.
echo(
echo   Or: open the Microsoft Store, search for "Python 3.12",
echo   install it, then run install.bat again.
echo  ==================================================================
echo(
if "%DBLCLK%"=="1" pause
exit /b 1
