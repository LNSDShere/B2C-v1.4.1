Prebuilt raylib 5.5 for 64-bit Windows (built with MinGW-w64 GCC 14,
flags: -O2 -DPLATFORM_DESKTOP -DGRAPHICS_API_OPENGL_33 -D_GLFW_WIN32).
dec uses this on Windows so kit programs run without building raylib.
If it is missing or unusable, dec builds raylib itself from vendor/raylib.
